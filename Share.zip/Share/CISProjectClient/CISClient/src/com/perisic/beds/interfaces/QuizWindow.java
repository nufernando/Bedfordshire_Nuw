package com.perisic.beds.interfaces;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JRadioButton;

import com.perisic.beds.others.UserDetails;
import com.perisic.beds.predefinemethods.RemoteConnection;
import com.perisic.beds.questionnaire.QuestionSet;
import com.perisic.beds.rmiinterface.RemoteQuestions;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class QuizWindow extends JInternalFrame {
	private QuestionSet questionnaire = new QuestionSet(); 
	private JTextField textField;
	public RemoteQuestions connection;
	private UserDetails user1= new UserDetails();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QuizWindow frame = new QuizWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws NotBoundException 
	 * @throws RemoteException 
	 * @throws MalformedURLException 
	 */
	public QuizWindow() throws Exception {
		connection = RemoteConnection.remoteConnect();
		user1=connection.getDeserializedUserDetails(); 
		setBounds(100, 100, 686, 480);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 177, 157));
		panel.setBounds(0, 0, 670, 469);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNext = new JButton("Start Quiz");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				for(int i = 0; i < questionnaire.numberOfQuestions(); i++) {
				String message = questionnaire.getQuestion(i);
				String [] options = questionnaire.getOptions(i); 

				JLabel label = new JLabel("");
				label.setFont(new Font("Century Gothic", Font.PLAIN, 20));
				label.setForeground(new Color(0, 177, 157));
				label.setText(message);
				
				
				int selectedValue =JOptionPane.showOptionDialog(null, label, "Question "+(i+1), JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null,options,options[0]);
				questionnaire.submitAnswer(i, options[selectedValue]);
				try {
					connection=RemoteConnection.remoteConnect();
					connection.setClientSubmission(i, options[selectedValue], user1.getUser_nic());
				} catch (Exception e) {
					// TODO: handle exception
				}
				
				}
				

			}
		});
		btnNext.setBackground(Color.WHITE);
		btnNext.setFont(new Font("Century Gothic", Font.BOLD, 20));
		btnNext.setBounds(247, 371, 182, 45);
		panel.add(btnNext);
		
		textField = new JTextField("Dear Customer,\n"
				+ "Kindly remind that you are able to\n"
				+ "submit answer for the each question once.\n\n"
				+ "Please be kind enough to give the answer inncently");
		textField.setFont(new Font("Century Gothic", Font.PLAIN, 23));
		textField.setBackground(new Color(0, 177, 157));
		textField.setBounds(29, 31, 606, 319);
		panel.add(textField);
		textField.setColumns(10);

	}
}
