package com.perisic.beds.interfaces;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.JButton;

public class ProfileWindow extends JInternalFrame {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfileWindow frame = new ProfileWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProfileWindow() {
		setBounds(100, 100, 686, 485);
		setBounds(100, 100, 686, 455);
		getContentPane().setLayout(null);
		
		JLabel lblBillNo = new JLabel("Bill No");
		lblBillNo.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblBillNo.setBounds(31, 13, 56, 29);
		getContentPane().add(lblBillNo);
		
		JLabel lblBranchCode = new JLabel("Branch Code");
		lblBranchCode.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblBranchCode.setBounds(31, 105, 108, 29);
		getContentPane().add(lblBranchCode);
		
		JLabel lblBranchLocation = new JLabel("Branch Location");
		lblBranchLocation.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblBranchLocation.setBounds(31, 58, 151, 29);
		getContentPane().add(lblBranchLocation);
		
		JLabel lblBranchManager = new JLabel("Branch Manager");
		lblBranchManager.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblBranchManager.setBounds(337, 148, 151, 29);
		getContentPane().add(lblBranchManager);
		
		JLabel lblPurchasedDate = new JLabel("Purchased Date");
		lblPurchasedDate.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblPurchasedDate.setBounds(31, 148, 151, 29);
		getContentPane().add(lblPurchasedDate);
		
		JLabel lblPurchasedTime = new JLabel("Purchased Time");
		lblPurchasedTime.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblPurchasedTime.setBounds(31, 190, 151, 29);
		getContentPane().add(lblPurchasedTime);
		
		JLabel lblCostOfThe = new JLabel("Cost of the Bill");
		lblCostOfThe.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblCostOfThe.setBounds(337, 13, 151, 29);
		getContentPane().add(lblCostOfThe);
		
		JLabel lblCashierName = new JLabel("Cashier ID");
		lblCashierName.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblCashierName.setBounds(337, 58, 151, 29);
		getContentPane().add(lblCashierName);
		
		JLabel lblCashierName_1 = new JLabel("Cashier Name");
		lblCashierName_1.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblCashierName_1.setBounds(337, 105, 151, 29);
		getContentPane().add(lblCashierName_1);
		
		JLabel lblEnterName = new JLabel("Name");
		lblEnterName.setForeground(Color.WHITE);
		lblEnterName.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblEnterName.setBounds(26, 257, 95, 29);
		getContentPane().add(lblEnterName);
		
		textField = new JTextField();
		textField.setBounds(143, 257, 188, 34);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel billNo = new JLabel("<Bill No>");
		billNo.setFont(new Font("Century Gothic", Font.BOLD, 17));
		billNo.setBounds(97, 13, 188, 29);
		getContentPane().add(billNo);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setForeground(Color.WHITE);
		lblAddress.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblAddress.setBounds(26, 300, 95, 29);
		getContentPane().add(lblAddress);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(143, 300, 188, 34);
		getContentPane().add(textField_1);
		
		JLabel lblTelephoneNo = new JLabel("Phone No");
		lblTelephoneNo.setForeground(Color.WHITE);
		lblTelephoneNo.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblTelephoneNo.setBounds(26, 343, 115, 29);
		getContentPane().add(lblTelephoneNo);
		
		JLabel label = new JLabel("<Branch Location>");
		label.setFont(new Font("Century Gothic", Font.BOLD, 17));
		label.setBounds(183, 58, 142, 29);
		getContentPane().add(label);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(143, 343, 188, 34);
		getContentPane().add(textField_2);
		
		JLabel label_2 = new JLabel("<Purchased Date>");
		label_2.setFont(new Font("Century Gothic", Font.BOLD, 17));
		label_2.setBounds(183, 148, 151, 29);
		getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("<Purchased Time>");
		label_3.setFont(new Font("Century Gothic", Font.BOLD, 17));
		label_3.setBounds(180, 190, 151, 29);
		getContentPane().add(label_3);
		
		JLabel label_4 = new JLabel("<Cost >");
		label_4.setFont(new Font("Century Gothic", Font.BOLD, 17));
		label_4.setBounds(473, 13, 151, 29);
		getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("<Cashier ID>");
		label_5.setFont(new Font("Century Gothic", Font.BOLD, 17));
		label_5.setBounds(441, 58, 151, 29);
		getContentPane().add(label_5);
		
		JLabel label_6 = new JLabel("<Cashier Name>");
		label_6.setFont(new Font("Century Gothic", Font.BOLD, 17));
		label_6.setBounds(473, 105, 151, 29);
		getContentPane().add(label_6);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setForeground(Color.WHITE);
		lblEmail.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblEmail.setBounds(26, 385, 115, 29);
		getContentPane().add(lblEmail);
		
		JLabel label_7 = new JLabel("<Branch Manager>");
		label_7.setFont(new Font("Century Gothic", Font.BOLD, 17));
		label_7.setBounds(484, 148, 174, 29);
		getContentPane().add(label_7);
		
		JLabel label_1 = new JLabel("<Branch Code>");
		label_1.setFont(new Font("Century Gothic", Font.BOLD, 17));
		label_1.setBounds(159, 105, 135, 29);
		getContentPane().add(label_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(143, 385, 188, 34);
		getContentPane().add(textField_3);
		
		JLabel lblFeedback = new JLabel("Feedback");
		lblFeedback.setForeground(Color.WHITE);
		lblFeedback.setFont(new Font("Century Gothic", Font.BOLD, 17));
		lblFeedback.setBounds(352, 257, 95, 29);
		getContentPane().add(lblFeedback);
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.setFont(new Font("Century Gothic", Font.BOLD, 20));
		btnNewButton.setBounds(353, 365, 135, 53);
		btnNewButton.setBackground(Color.WHITE);
		getContentPane().add(btnNewButton);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(353, 284, 282, 73);
		getContentPane().add(textArea);
		
		JButton btnClear = new JButton("Clear");
		btnClear.setForeground(Color.WHITE);
		btnClear.setFont(new Font("Century Gothic", Font.BOLD, 20));
		btnClear.setBounds(500, 365, 135, 53);
		btnClear.setBackground(new Color(220, 20, 60));
		getContentPane().add(btnClear);
		
		JLabel lblNewLabel = new JLabel("Customer Name");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\User\\Documents\\CISProjectClient\\CISClient\\images\\profileWindow.jpg"));
		lblNewLabel.setBounds(0, -25, 670, 503);
		getContentPane().add(lblNewLabel);

	}
}
