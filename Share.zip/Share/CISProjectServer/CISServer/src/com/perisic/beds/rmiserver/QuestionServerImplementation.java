package com.perisic.beds.rmiserver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JOptionPane;

import com.perisic.beds.others.UserDetails;
import com.perisic.beds.others.UserSatisfactionAnswers;
import com.perisic.beds.predefinemethods.DBMethods;
import com.perisic.beds.rmiinterface.Question;
import com.perisic.beds.rmiinterface.RemoteQuestions;

/**
 * Implementation of the questionnaire. Note that chosen answers are collected in this
 * object as well. That means that if the object is destroyed, for instance server restart
 * the collected data is all gone. 
 * To do: make data persistent, for instance link collected data to a database or save data
 * in a text file.  
 * @author Nuwantha Fernando
 *
 */
public class QuestionServerImplementation 
extends UnicastRemoteObject implements RemoteQuestions{
	PreparedStatement pst;
	private static final long serialVersionUID = -3763231206310491048L;
	Vector<Question> myQuestions = new Vector<Question>(); 
	/**
	 * All questions and answers are initialised in the constructor of this class. 
	 * To do: read questions and options from an external data file. 
	 * @throws RemoteException
	 */
	QuestionServerImplementation() throws RemoteException {
		super();
		System.out.println("QuestionServerImplementation Created");
		//Yes, No, Maybe Answers
		String[] answers = {"Yes", "No", "Maybe" }; 
		
		//Satisfaction Answers
		String[] answers1 = {"Very Satisfied", "Satisfied", "Neutral", "Dissatisfied", "Very dissatisfied" }; 
		
		//Agree, Disagree Answers
		String[] answers2 = {"Strongly Agree", "Agree", "Neutral", "Disagree", "Strongly Disagree" }; 
		
		//Yes, No, Maybe Questions
		Question question1 = new Question("Did the Cashier process the transaction quickly and effectively?", answers ); 
		myQuestions.add(question1); 

		Question question2 = new Question("Did the store have a reasonable return and exchange policy?", answers );
		myQuestions.add(question2); 
		
		
		//Satisfaction Questions 
		Question question3 = new Question("The interaction with the sales staff?", answers1 ); 
		myQuestions.add(question3); 
		
		Question question4 = new Question("Helpfulness of Staff?", answers1 ); 
		myQuestions.add(question4); 
		
		Question question5 = new Question("The Organization of the store?", answers1 ); 
		myQuestions.add(question5); 
		
		Question question6 = new Question("The products offered in the store?", answers1 ); 
		myQuestions.add(question6); 
		
		Question question7 = new Question("The price of the Products?", answers1 ); 
		myQuestions.add(question7);
		
		Question question8 = new Question("The Sizes available at the store?", answers1 ); 
		myQuestions.add(question8); 
		
		Question question9 = new Question("Parking facility provide by the company?", answers1 ); 
		myQuestions.add(question9); 
		
		
		//Agree, Disagree Questions
		Question question10 = new Question("Service representatives are well trained?", answers2 ); 
		myQuestions.add(question10); 
		
		Question question11 = new Question("Service representatives adhere to professional standards of conduct?", answers2 ); 
		myQuestions.add(question11); 
		
		Question question12 = new Question("Service representatives adhere to professional standards of conduct?", answers2 ); 
		myQuestions.add(question12); 
		

	}

	/**
	 * Implementation of remote interface method. 
	 */
	@Override
	public int getNumberOfQuestions() throws RemoteException {
		return myQuestions.size();
	}
	/**
	 * Implementation of remote interface method. 
	 */
	@Override
	public Question getQuestion(int i) throws RemoteException {
		return myQuestions.elementAt(i);
	}
	/**
	 * Implementation of remote interface method. 
	 */	
	@Override
	public void submitAnswer(int i, String answer) throws RemoteException {
		myQuestions.elementAt(i).addAnswer(answer);
	}
	/**
	 * Implementation of remote interface method. 
	 */	
	@Override
	public Vector<Question> getData() throws RemoteException {
		return myQuestions; 
	}


	@Override
	public String getName(int billNo) throws Exception {
		String qry="SELECT c.name FROM clientdata c, billinfo r WHERE c.nic=r.nic AND r.bill_no="+billNo;
		String user_name="";
			ResultSet rst=DBMethods.getREsultSet(qry);
			while(rst.next()){
				user_name = rst.getString("name");
			}
	        rst.close();

		System.out.println("Server Side : getName : getName Success");
		return user_name;
	}

//Method to Validate the Bill No
	@Override
	public boolean validateBillNo(long billNo) throws RemoteException {
		
		String qry="SELECT bill_no FROM billinfo";
		try {
			ResultSet rst=DBMethods.getREsultSet(qry);
			while(rst.next()){
	            long user_billNo = Long.parseLong(rst.getString("bill_no"));
	            if(user_billNo==billNo) {
	            	return true;
	            }  
	        }
	        rst.close();
		} catch (Exception e) {
			System.err.println(e);
		}
		System.out.println("Server Side : validateBillNo : Bill No Successfully Validated.");
		return false;
	}

	@Override
	public void getSerializedUserDetails(long billNo) throws RemoteException {
		UserDetails user1=new UserDetails();
		String filename="error";
		String qry="SELECT c.*,b.bill_no FROM clientdata c, billinfo b WHERE c.nic=b.nic AND b.bill_no="+billNo;
		try {
			ResultSet rst=DBMethods.getREsultSet(qry);
			while(rst.next()){
				String user_nic = rst.getString("nic");
				user1.setUser_nic(user_nic);
				
	            String user_firstname = rst.getString("name");
	            user1.setUser_firstname(user_firstname);
	            
	            String user_lastname = rst.getString("last_name");
	            user1.setUser_lastname(user_lastname);
	            
	            String user_fullname = user_firstname+" "+user_lastname;
	            user1.setUser_fullname(user_fullname);
	            
	            String user_address = rst.getString("address");
	            user1.setUser_address(user_address);
	            
	            int user_phoneNo = Integer.parseInt(rst.getString("phone_no"));
	            user1.setUser_phoneNo(user_phoneNo);
	            
	            String user_email = rst.getString("email");
	            user1.setUser_email(user_email);
	            
	            String user_feedback= rst.getString("feedback");
	            user1.setUser_feedback(user_feedback);
	            
	            String user_type =rst.getString("type");
	            user1.setUser_type(user_type);
	            
	            long user_billNo= Long.parseLong(rst.getString("bill_no"));
	            user1.setUser_billNo(user_billNo);
	            
	            filename="serialized_user_details";
	            
	        }
	        rst.close();
		} catch (Exception e) {
			System.err.println(e);
		}
		
		try {
			FileOutputStream fileout = new FileOutputStream("C:\\Users\\User\\Documents\\CISProjectClient\\CISClient\\SerializedFiles\\"+filename+".txt");
			ObjectOutputStream out = new ObjectOutputStream(fileout);
			out.writeObject(user1);
			out.close();
			fileout.close();
			System.out.println("Server Side : getSerializedUserDetails : Serialization is success");
		} catch (Exception e) {
			System.err.println(e);
		}
		
		
	}

	@Override
	public UserDetails getDeserializedUserDetails() throws Exception {
		UserDetails user= new UserDetails();
		String filename="serialized_user_details";
		FileInputStream fileIn = new FileInputStream("C:\\Users\\User\\Documents\\CISProjectClient\\CISClient\\SerializedFiles\\"+filename+".txt");
		ObjectInputStream in = new ObjectInputStream(fileIn);
		user = (UserDetails)in.readObject();
		in.close();
		fileIn.close();
		System.out.println("Server Side : getDeserializedUserDetails : Deserialization is success");
		return user;
		
	}

	@Override
	public boolean checkRegistrationStatus(long billNo) throws Exception {
		String qry="SELECT c.registration FROM clientdata c, billinfo b WHERE c.nic=b.nic AND b.bill_no="+billNo;
		
			ResultSet rst=DBMethods.getREsultSet(qry);
			boolean status=false;
			while(rst.next()){
				status = Boolean.parseBoolean(rst.getString("registration"));   
	        }
	        rst.close();
	
		System.out.println("Server Side : checkRegistrationStatus : Registration Status Successfully returned.");
		return status;
	}
	

	@Override
	public int getWiningProgree(int nic) throws Exception {
		String qry="SELECT winningPorgress FROM clientdata WHERE nic="+nic;
		ResultSet rst=DBMethods.getREsultSet(qry);
		int status = 0;
		while(rst.next()){
			status = Integer.getInteger(rst.getString("winningPorgress"));   
        }
        rst.close();
        System.out.println("Server Side : getWiningProgree : Winning Progress get Successfully.");
		return status;
	}

	@Override
	public void setClientSubmission(int qID, String answer, String nic) throws Exception {
		String qry="UPDATE satisficationtable SET question_"+qID+" = '"+answer+"' WHERE nic ="+nic;
		pst=DBMethods.prepare(qry);
		pst.execute();
		
		System.out.println("Server : setClientSubmission : SatisficationTable Updated");
		
	}

	@Override
	public void createSatisficationTableColumn(String nic) throws Exception {
		String qry="INSERT INTO satisficationtable(nic)VALUES("+nic+")";
		pst=DBMethods.prepare(qry);
		pst.execute();
		
		System.out.println("Server : setClientSubmission : Insert Row into SatisficationTable ");
	}

	@Override
	public void getSerializedUserSatisficationAnswers(int nic) throws RemoteException {
		UserSatisfactionAnswers user1= new UserSatisfactionAnswers();
		String filename="Satisfication_answerFile_error";
		String qry="SELECT * FROM satisficationtable WHERE nic="+nic;
		try {
			ResultSet rst=DBMethods.getREsultSet(qry);
			while(rst.next()){
				String q0=rst.getString("question_0");
				user1.setQuestion_0(q0);
				
				String q1=rst.getString("question_1");
				user1.setQuestion_0(q1);
				
				String q2=rst.getString("question_2");
				user1.setQuestion_0(q2);
				
				String q3=rst.getString("question_3");
				user1.setQuestion_0(q3);
				
				String q4=rst.getString("question_4");
				user1.setQuestion_0(q4);
				
				String q5=rst.getString("question_5");
				user1.setQuestion_0(q5);
				
				String q6=rst.getString("question_6");
				user1.setQuestion_0(q6);
				
				String q7=rst.getString("question_7");
				user1.setQuestion_0(q7);
				
				String q8=rst.getString("question_8");
				user1.setQuestion_0(q8);
				
				String q9=rst.getString("question_9");
				user1.setQuestion_0(q9);
				
				String q10=rst.getString("question_10");
				user1.setQuestion_0(q10);
				
				String q11=rst.getString("question_11");
				user1.setQuestion_0(q11);
			}
			rst.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			FileOutputStream fileout = new FileOutputStream("C:\\Users\\User\\Documents\\CISProjectClient\\CISClient\\SerializedFiles\\"+filename+".txt");
			ObjectOutputStream out = new ObjectOutputStream(fileout);
			out.writeObject(user1);
			out.close();
			fileout.close();
			System.out.println("Server Side : getSerializedUserDetails : Serialization is success");
		} catch (Exception e) {
			System.err.println(e);
		}
		
	}

	@Override
	public String[][] getClientsSatisficationAnswers() throws Exception {
		String qry="SELECT COUNT(*)AS numberofrows FROM satisficationtable";
		ResultSet rst=DBMethods.getREsultSet(qry);
		int rowCount=0;
		
		
		while(rst.next()){
			rowCount = Integer.parseInt(rst.getString("numberofrows"));   
        }
        rst.close();
        
        
        String value[][] = null;
       
        rst.close();
        for(int x=0;x<rowCount;x++) {
        	String qry1="SELECT * FROM satisficationtable WHERE rowid="+(x+1);
            ResultSet rst1=DBMethods.getREsultSet(qry1);
        	 while(rst1.next()){
        		 
     			String nic = rst.getString("nic");
     			value[x][0]=nic;
     			String q0 = rst.getString("question_0"); 
     			value[x][1]=q0;
     			String q1 = rst.getString("question_1"); 
     			value[x][2]=q1;
     			String q2 = rst.getString("question_2"); 
     			value[x][3]=q2;
     			String q3 = rst.getString("question_3"); 
     			value[x][4]=q3;
     			String q4 = rst.getString("question_4"); 
     			value[x][5]=q4;
     			String q5 = rst.getString("question_5"); 
     			value[x][6]=q5;
     			String q6 = rst.getString("question_6"); 
     			value[x][7]=q6;
     			String q7 = rst.getString("question_7"); 
     			value[x][8]=q7;
     			String q8 = rst.getString("question_8"); 
     			value[x][9]=q8;
     			String q9 = rst.getString("question_9"); 
     			value[x][10]=q9;
     			String q10 = rst.getString("question_10"); 
     			value[x][11]=q10;
     			String q11 = rst.getString("question_11"); 
     			value[x][12]=q11;
             }
        		
        }
		return value;
	}

	@Override
	public void setUsernameAndPassword(String username, String password, String nic) throws Exception {
		String qry="UPDATE clientdata SET username= '"+username+"',password='"+password+"' WHERE nic ="+nic;
		pst=DBMethods.prepare(qry);
		pst.execute();
		
		System.out.println("Server : setUsernameAndPassword : Username and Password Successcully Added");
		
	}

	@Override
	public void updateRegistration(String nic) throws Exception {
		String qry="UPDATE clientdata SET registration= 'true' WHERE nic ="+nic;
		pst=DBMethods.prepare(qry);
		pst.execute();
		
		System.out.println("Server : setUsernameAndPassword : Succesully registartion Column Updated");
	}

	@Override
	public String getPasswordFromUsername(String username) throws Exception {
		String qry="SELECT password FROM clientdata WHERE username='"+username+"'";
		
		ResultSet rst=DBMethods.getREsultSet(qry);
		String pass="";
		while(rst.next()){
			pass = rst.getString("password");   
        }
        rst.close();

	System.out.println("Server Side : getPasswordFromUsername : Password Successfully Returned");
	return pass;
	}
//
	@Override
	public int getAnswerCountYesNoQuiz(String quiz, String ans) throws Exception {
		String qry="Select count(*) as numberofAnswers from satisficationtable where '"+quiz+"'='"+quiz+"'";
		ResultSet rst=DBMethods.getREsultSet(qry);
		int count=0;
		
		
		while(rst.next()){
			count = Integer.parseInt(rst.getString("numberofAnswers"));   
        }
        rst.close();
		return count;
	}

	
	



	

}
