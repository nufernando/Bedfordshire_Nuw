/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.perisic.beds.predefinemethods;

/**
 * @author Numwantha 
 * @author Kavindi
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.perisic.beds.connection.DBconnection;


/**
 *
 * @author intern1
 */
public class DBMethods {
    public static ResultSet getREsultSet(String aq) throws Exception {
       
        Connection conn=DBconnection.connect();
        Statement state=conn.prepareStatement(aq);
      
      return  state.executeQuery(aq);
    }
     
    public static boolean execute(String aq) throws Exception {
       
        Connection conn=DBconnection.connect();
        Statement state=conn.createStatement();
      
      return  state.executeUpdate(aq)>0;
      
    }
    
    public static PreparedStatement prepare(String qry)throws Exception {
    	Connection conn=DBconnection.connect();
    	PreparedStatement pst=conn.prepareStatement(qry);
    	return pst;
    	
    }
}
