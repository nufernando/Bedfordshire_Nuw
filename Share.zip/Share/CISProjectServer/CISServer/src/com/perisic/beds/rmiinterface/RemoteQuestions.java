package com.perisic.beds.rmiinterface;
import java.io.FileNotFoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Vector;

import com.perisic.beds.others.UserDetails;
/**
 * RMI interface to enable to retrieve questions from the server and to submit data
 * to the server. 
 * @author Nuwantha Fernando
 *
 */
public interface RemoteQuestions extends Remote {
	/**
	 * Number of questions on the server.
	 * @return
	 * @throws RemoteException
	 */
	public int getNumberOfQuestions() throws RemoteException; 
	/**
	 * Retrieve specific question from the server. 
	 * @param i number of the question. 
	 * @return the Question. 
	 * @throws RemoteException
	 */
	public Question getQuestion(int i) throws RemoteException; 
	/**
	 * Submit the answer to the question number i.
	 * @param i question where the answer belongs to.
	 * @param answer the answer given to this question. 
	 * @throws RemoteException
	 */
	void submitAnswer(int i, String answer) throws RemoteException;  
	/**
	 * Returns the answers to the questions given. 
	 * @return answers to the questions. 
	 * @throws RemoteException
	 */
	public Vector<Question> getData() throws RemoteException; 
	
	//********************************************************************************************************************
	
	
	public String getName(int billNo)throws RemoteException, Exception; 
	
	public boolean validateBillNo(long billNo)throws RemoteException;
	
	public void getSerializedUserDetails(long billNo)throws RemoteException;
	
	public UserDetails getDeserializedUserDetails()throws Exception;
	
	public boolean checkRegistrationStatus(long billNo)throws Exception;
	
	public int getWiningProgree(int nic) throws Exception;
	
	public void setClientSubmission(int qID, String answer, String nic)throws Exception;
	
	public void createSatisficationTableColumn(String nic)throws Exception;
	
	public void getSerializedUserSatisficationAnswers(int nic)throws RemoteException;
	
	public String[][] getClientsSatisficationAnswers()throws Exception;
	
	public void setUsernameAndPassword(String username,String password,String nic)throws Exception;
	
	public void updateRegistration(String nic)throws Exception;
	
	public String getPasswordFromUsername(String username)throws Exception;
	
	public int getAnswerCountYesNoQuiz (String quiz, String ans)throws Exception;
	
	
}
